MINT AFTERHOURS / KID BUNKA
Pocket Tracker Extreme public-beta showcase project

An original 3:28.684 instrumental built as 80 authored 4/4 tracker bars at 92 BPM.
Warm modal keys and a swung hip-hop rhythm open into a double-time breakbeat section,
then return to the original pocket. The tempo stays at 92 BPM throughout; the middle
section has a 184-BPM rhythmic feel. All melody, bass and rhythmic events are stored
in the editable tracker project, rather than hidden in a finished backing-track sample.

INSTALL / OPEN
Copy the complete Mint_Afterhours folder, including its Samples subfolder, into your
Pocket Tracker Extreme project area. Open Mint_Afterhours.ptp through PROJECT > LOAD.
The project-relative sample paths are portable. Keep the Samples folder beside the project.
Start playback from song row 00. There are 20 song rows; each chain contains four bars.

SOUND SOURCES
Eight sequencer tracks: kick, snare/rim, hats/shaker, bass, Rhodes chords, lead,
air pads, percussion/transitions. Twenty-two instrument slots are used.
Instrument 11 hex (17 decimal) is an active Plaits modal voice.
Instrument 12 hex (18 decimal) is an active Studio Karplus nylon voice.
The other instruments are original samples synthesized specifically for this project.
The Rhodes and pad instruments are chord samples, so the full composition remains
playable inside the eight-track arrangement without claiming independent polyphony.

RENDER / MASTER
The final WAV is the direct 48-kHz stereo PCM16 export produced by the same SongcoreHost
and AudioEngine used by the application, linked from the canonical public-beta source.
No replacement backing music, generative-music model or external music mastering was used.
The authored Studio master chain applies gentle compression, subtle color, high-pass
control, width and output gain. The final bar contains the master fade.
Measured integrated loudness: -15.27 LUFS. Measured true peak: -4.02 dBTP.
Loudness range: 8.20 LU. Zero clipped PCM samples. Duration: 208.684 seconds.
Listening and final artistic approval remain part of the creator's video review.

LICENSE
Original composition and original sample assets: CC BY 4.0, Kid Bunka.
See LICENSE-CONTENT.txt. Application and renderer software licenses remain separate.
