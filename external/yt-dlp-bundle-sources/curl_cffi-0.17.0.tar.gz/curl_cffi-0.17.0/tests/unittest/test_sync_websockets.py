"""
Comprehensive test suite for the Synchronous WebSocket implementation.

This module provides reusable, composable test infrastructure for testing
the WebSocket class across various scenarios including:
- Basic connectivity and message exchange
- Different message types (binary, text, JSON)
- Timeout behavior and socket stalls
- Error propagation and handling
- Large message fragmentation and SIMD boundaries
- Callback-driven run_forever() architecture
- Connection lifecycle management
- Thread-safety of the C-layer SIMD state
- High volume performance checks
- Strict Protocol Spec Compliance
"""

from __future__ import annotations

import asyncio
import concurrent.futures
import queue
import struct
import threading
import time
import unittest.mock
from collections.abc import Awaitable, Callable, Generator, Iterator
from concurrent.futures import Future
from dataclasses import dataclass, field
from enum import Enum, auto
from json import JSONDecodeError
from typing import Final, Literal
from unittest.mock import MagicMock, Mock

import pytest
import websockets
from websockets.exceptions import ConnectionClosedError, ConnectionClosedOK

from curl_cffi import (
    Curl,
    CurlECode,
    CurlError,
    CurlOpt,
    CurlWsFlag,
    ProxySpec,
    Response,
    Session,
    WebSocket,
    WebSocketClosed,
    WebSocketError,
    WebSocketRetryStrategy,
    WebSocketTimeout,
    WsCloseCode,
)


class _StopBeforeIO(Exception):
    """Aborts a connect once the options are set, so no socket is opened."""


class ServerBehavior(Enum):
    ECHO = auto()
    BROADCAST = auto()
    CLOSE_IMMEDIATELY = auto()
    CLOSE_AFTER_N = auto()
    SILENT = auto()
    LARGE_RESPONSE = auto()
    SEND_PINGS = auto()


@dataclass
class ServerConfig:
    behavior: ServerBehavior = ServerBehavior.ECHO
    delay_seconds: float = 0.0
    close_after_n: int = 1
    broadcast_messages: list[bytes | str] = field(default_factory=list)
    response_size: int = 1024
    close_code: int = WsCloseCode.OK
    close_reason: str = ""


async def echo_handler(ws: websockets.ServerConnection, config: ServerConfig) -> None:
    try:
        async for msg in ws:
            if config.delay_seconds > 0:
                await asyncio.sleep(config.delay_seconds)
            await ws.send(msg)
    except (ConnectionClosedOK, ConnectionClosedError):
        pass


async def broadcast_handler(
    ws: websockets.ServerConnection, config: ServerConfig
) -> None:
    try:
        for msg in config.broadcast_messages:
            await ws.send(msg)
        async for _ in ws:
            pass
    except (ConnectionClosedOK, ConnectionClosedError):
        pass


async def send_pings_handler(
    ws: websockets.ServerConnection, _config: ServerConfig
) -> None:
    try:
        _ = await ws.ping(b"server_ping_1")
        await asyncio.sleep(0.05)
        await ws.send(b"data_1")
        _ = await ws.ping(b"server_ping_2")
        await asyncio.sleep(0.05)
        await ws.send(b"data_2")
        async for _ in ws:
            pass
    except (ConnectionClosedOK, ConnectionClosedError):
        pass


async def close_immediately_handler(
    ws: websockets.ServerConnection, config: ServerConfig
) -> None:
    await ws.close(config.close_code, config.close_reason)


async def close_after_n_handler(
    ws: websockets.ServerConnection, config: ServerConfig
) -> None:
    try:
        count = 0
        async for msg in ws:
            await ws.send(msg)
            count += 1
            if count >= config.close_after_n:
                await ws.close(config.close_code, config.close_reason)
                return
    except (ConnectionClosedOK, ConnectionClosedError):
        pass


async def silent_handler(
    ws: websockets.ServerConnection, _config: ServerConfig
) -> None:
    try:
        async for _ in ws:
            pass
    except (ConnectionClosedOK, ConnectionClosedError):
        pass


async def large_response_handler(
    ws: websockets.ServerConnection, config: ServerConfig
) -> None:
    try:
        async for _ in ws:
            await ws.send(b"X" * config.response_size)
    except (ConnectionClosedOK, ConnectionClosedError):
        pass


_MAX_FRAME: Final[int] = (
    WebSocket._MAX_CURL_FRAME_SIZE
)  # pyright: ignore[reportPrivateUsage]
DEFAULT_SERVER_MAX_SIZE: Final[int] = 32 * 1024 * 1024


def _pattern(size: int) -> bytes:
    """Non-uniform payload: 251 is coprime with the frame size and the mask
    width, so reordering or duplication shows up in an equality check."""
    return (bytes(range(251)) * (size // 251 + 1))[:size]


def _text_pattern(size: int) -> str:
    """UTF-8 safe counterpart to _pattern. Period 95 is coprime with the frame
    size and the mask width."""
    block: str = "".join(chr(32 + i) for i in range(95))
    return (block * (size // 95 + 1))[:size]


HANDLERS: dict[ServerBehavior, Callable[..., Awaitable[None]]] = {
    ServerBehavior.ECHO: echo_handler,
    ServerBehavior.BROADCAST: broadcast_handler,
    ServerBehavior.CLOSE_IMMEDIATELY: close_immediately_handler,
    ServerBehavior.CLOSE_AFTER_N: close_after_n_handler,
    ServerBehavior.SILENT: silent_handler,
    ServerBehavior.LARGE_RESPONSE: large_response_handler,
    ServerBehavior.SEND_PINGS: send_pings_handler,
}


@dataclass
class ConfigurableWSServer:
    url: str
    port: int
    stop: Callable[[], None]
    set_config: Callable[[ServerConfig], None]
    _thread: threading.Thread

    def configure(self, **kwargs) -> None:
        self.set_config(ServerConfig(**kwargs))


def start_configurable_ws_server(
    port: int = 0, max_size: int = DEFAULT_SERVER_MAX_SIZE
) -> ConfigurableWSServer:
    ready: threading.Event = threading.Event()
    stop_q: queue.Queue[Callable[[], None]] = queue.Queue()
    port_q: queue.Queue[int] = queue.Queue()
    config_holder: list[ServerConfig] = [ServerConfig()]

    def set_config(cfg: ServerConfig) -> None:
        config_holder[0] = cfg

    def _thread_target() -> None:
        loop: asyncio.AbstractEventLoop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        stop_event: asyncio.Event = asyncio.Event()

        def _stop() -> None:
            _ = loop.call_soon_threadsafe(stop_event.set)

        async def handler(ws: websockets.ServerConnection) -> None:
            cfg: ServerConfig = config_holder[0]
            handler_fn: Callable[..., Awaitable[None]] = HANDLERS.get(
                cfg.behavior, echo_handler
            )
            await handler_fn(ws, cfg)

        async def _run() -> None:
            async with websockets.serve(
                handler, "127.0.0.1", port, max_size=max_size
            ) as server:
                port_q.put(int(server.sockets[0].getsockname()[1]))
                stop_q.put(_stop)
                ready.set()
                _ = await stop_event.wait()

        try:
            loop.run_until_complete(_run())
        finally:
            loop.run_until_complete(loop.shutdown_asyncgens())
            loop.close()

    t: threading.Thread = threading.Thread(target=_thread_target, daemon=True)
    t.start()

    bound_port: int = port_q.get()
    stop: Callable[[], None] = stop_q.get()
    _ = ready.wait()

    return ConfigurableWSServer(
        url=f"ws://127.0.0.1:{bound_port}",
        port=bound_port,
        stop=stop,
        set_config=set_config,
        _thread=t,
    )


# =============================================================================
# Fixtures
# =============================================================================


@pytest.fixture(scope="module")
def configurable_ws_server() -> Generator[ConfigurableWSServer, None, None]:
    server: ConfigurableWSServer = start_configurable_ws_server()
    try:
        yield server
    finally:
        server.stop()
        server._thread.join(timeout=5)


@pytest.fixture
def ws_config(configurable_ws_server: ConfigurableWSServer) -> Callable[..., None]:
    configurable_ws_server.set_config(ServerConfig())

    def configure(**kwargs) -> None:
        configurable_ws_server.set_config(ServerConfig(**kwargs))

    return configure


@pytest.fixture
def session() -> Iterator[Session]:
    with Session[Response]() as s:
        yield s


@pytest.fixture
def ws_connection(
    session: Session,
    configurable_ws_server: ConfigurableWSServer,
    ws_config: Callable[..., None],
) -> Iterator[WebSocket]:
    ws_config()
    with session.ws_connect(configurable_ws_server.url) as ws:
        yield ws


# =============================================================================
# Test Classes
# =============================================================================


class TestWebSocketBasicConnectivity:
    def test_connect_and_close(
        self,
        session: Session,
        configurable_ws_server: ConfigurableWSServer,
    ) -> None:
        ws: WebSocket = session.ws_connect(configurable_ws_server.url)
        assert not ws.closed
        ws.close()
        assert ws.closed

    def test_context_manager(
        self,
        session: Session,
        configurable_ws_server: ConfigurableWSServer,
    ) -> None:
        with session.ws_connect(configurable_ws_server.url) as ws:
            assert not ws.closed
        assert ws.closed

    def test_echo_single_message(self, ws_connection: WebSocket) -> None:
        _ = ws_connection.send(b"hello", timeout=5.0)
        data, flags = ws_connection.recv(timeout=5.0)
        assert data == b"hello"
        assert flags & CurlWsFlag.BINARY

    def test_echo_multiple_messages(self, ws_connection: WebSocket) -> None:
        for i in range(10):
            msg: str = f"message_{i}"
            _ = ws_connection.send_str(msg, timeout=5.0)
            response: str = ws_connection.recv_str(timeout=5.0)
            assert response == msg

    def test_invalid_socket_handle(self) -> None:
        """Verifies that an uninitialized or broken libcurl socket throws correctly."""
        mock_curl: Mock = Mock(spec=Curl)
        mock_curl.getinfo.return_value = -1
        ws: WebSocket = WebSocket(curl=mock_curl)
        with pytest.raises(WebSocketError) as exc:
            _ = ws._get_sock_fd()
        assert exc.value.code == CurlECode.NO_CONNECTION_AVAILABLE


class TestWebSocketMessageTypes:
    def test_send_recv_binary(self, ws_connection: WebSocket) -> None:
        payload = b"\x00\x01\x02\xff\xfe"
        _ = ws_connection.send_binary(payload, timeout=5.0)
        data, flags = ws_connection.recv(timeout=5.0)
        assert data == payload
        assert flags & CurlWsFlag.BINARY

    def test_send_recv_text(self, ws_connection: WebSocket) -> None:
        payload = "Hello, WebSocket! 你好 🎉"
        _ = ws_connection.send_str(payload, timeout=5.0)
        response: str = ws_connection.recv_str(timeout=5.0)
        assert response == payload

    def test_send_recv_json(self, ws_connection: WebSocket) -> None:
        payload: dict[str, str | int | dict[str, int]] = {
            "key": "value",
            "number": 42,
            "nested": {"a": 1},
        }
        _ = ws_connection.send_json(payload, timeout=5.0)
        assert ws_connection.recv_json(timeout=5.0) == payload

    def test_send_bytearray(self, ws_connection: WebSocket) -> None:
        payload: bytearray = bytearray(b"bytearray_test")
        _ = ws_connection.send(payload, timeout=5.0)
        data, _ = ws_connection.recv(timeout=5.0)
        assert data == bytes(payload)

    def test_send_memoryview(self, ws_connection: WebSocket) -> None:
        original = b"memoryview_test"
        payload: memoryview = memoryview(original)
        _ = ws_connection.send(payload, timeout=5.0)
        data, _ = ws_connection.recv(timeout=5.0)
        assert data == original

    def test_recv_str_invalid_utf8(self, ws_connection: WebSocket) -> None:
        _ = ws_connection.send(b"\xff\xfe", timeout=5.0)
        with pytest.raises(WebSocketError) as exc_info:
            ws_connection.recv_str(timeout=5.0)
        assert exc_info.value.code == WsCloseCode.INVALID_DATA

    def test_recv_json_invalid(self, ws_connection: WebSocket) -> None:
        _ = ws_connection.send_str("not valid json {", timeout=5.0)
        with pytest.raises(JSONDecodeError):
            ws_connection.recv_json(timeout=5.0)

    def test_server_ping_is_silently_consumed(
        self,
        session: Session,
        configurable_ws_server: ConfigurableWSServer,
        ws_config: Callable[..., None],
    ) -> None:
        ws_config(behavior=ServerBehavior.SEND_PINGS)
        with session.ws_connect(configurable_ws_server.url) as ws:
            data1, flags1 = ws.recv(timeout=2.0)
            assert data1 == b"data_1"
            assert not (flags1 & CurlWsFlag.PING)

            data2, flags2 = ws.recv(timeout=2.0)
            assert data2 == b"data_2"
            assert not (flags2 & CurlWsFlag.PING)

            with pytest.raises(WebSocketTimeout):
                _ = ws.recv(timeout=0.2)

    def test_pong_is_silently_consumed(
        self,
        session: Session,
        configurable_ws_server: ConfigurableWSServer,
        ws_config: Callable[..., None],
    ) -> None:
        ws_config(behavior=ServerBehavior.SILENT)
        with session.ws_connect(configurable_ws_server.url) as ws:
            _ = ws.ping(b"heartbeat", timeout=2.0)
            # The server will send a PONG. The sync hot-loop must discard it.
            with pytest.raises(WebSocketTimeout):
                _ = ws.recv(timeout=0.5)

    def test_recv_json_empty(
        self,
        session: Session,
        configurable_ws_server: ConfigurableWSServer,
        ws_config: Callable[..., None],
    ) -> None:
        """Test recv_json raises on empty payload."""
        ws_config(behavior=ServerBehavior.BROADCAST, broadcast_messages=[""])
        with (
            session.ws_connect(configurable_ws_server.url) as ws,
            pytest.raises(JSONDecodeError),
        ):
            _ = ws.recv_json()


class TestWebSocketTimeouts:
    def test_recv_timeout(
        self,
        session: Session,
        configurable_ws_server: ConfigurableWSServer,
        ws_config: Callable[..., None],
    ) -> None:
        ws_config(behavior=ServerBehavior.SILENT)
        with session.ws_connect(configurable_ws_server.url) as ws:
            _ = ws.send(b"hello", timeout=2.0)
            with pytest.raises(WebSocketTimeout):
                ws.recv(timeout=0.2)

    def test_recv_timeout_returns_early(self, ws_connection: WebSocket) -> None:
        _ = ws_connection.send_str("quick", timeout=2.0)
        response: str = ws_connection.recv_str(timeout=5.0)
        assert response == "quick"

    def test_send_timeout_during_eagain_loop(self) -> None:
        """Proves that a timeout properly fires even if stuck mid-EAGAIN loop."""
        mock_curl: Mock = Mock(spec=Curl)
        ws: WebSocket = WebSocket(curl=mock_curl)
        ws.closed = False
        ws._sock_fd = 999
        mock_selector: Mock = Mock()
        ws._read_selector = mock_selector
        ws._write_selector = mock_selector

        # Raise EAGAIN every time
        mock_curl.ws_send.side_effect = CurlError("EAGAIN", CurlECode.AGAIN)

        # Let select mock simulate time passing beyond the timeout
        def mock_select(timeout) -> Literal[False]:
            time.sleep(0.06)  # Force clock advance past the 0.05 deadline
            return False

        mock_selector.select.side_effect = mock_select

        with pytest.raises(WebSocketTimeout):
            ws.send(b"data", timeout=0.05)


class TestWebSocketEdgeCases:
    def test_empty_message(self, ws_connection: WebSocket) -> None:
        _ = ws_connection.send(b"", timeout=5.0)
        data, _ = ws_connection.recv(timeout=5.0)
        assert data == b""

    def test_empty_string_message(self, ws_connection: WebSocket) -> None:
        _ = ws_connection.send_str("", timeout=5.0)
        response: str = ws_connection.recv_str(timeout=5.0)
        assert response == ""

    def test_unicode_edge_cases(self, ws_connection: WebSocket) -> None:
        test_strings: list[str] = [
            "",
            "a",
            "🎉",
            "Hello 世界 🌍",
            "\u0000",
            "a" * 10000,
        ]
        for s in test_strings:
            _ = ws_connection.send_str(s, timeout=5.0)
            response: str = ws_connection.recv_str(timeout=5.0)
            assert response == s

    def test_binary_all_byte_values(self, ws_connection: WebSocket) -> None:
        payload: bytes = bytes(range(256))
        _ = ws_connection.send(payload, timeout=5.0)
        data, _ = ws_connection.recv(timeout=5.0)
        assert data == payload

    def test_rapid_send_recv(self, ws_connection: WebSocket) -> None:
        for i in range(100):
            msg: str = f"rapid_{i}"
            _ = ws_connection.send_str(msg, timeout=2.0)
            response: str = ws_connection.recv_str(timeout=2.0)
            assert response == msg


class TestWebSocketPing:
    def test_ping_valid_payload(self, ws_connection: WebSocket) -> None:
        _ = ws_connection.ping(b"heartbeat", timeout=2.0)
        assert not ws_connection.closed

    def test_ping_empty_payload(self, ws_connection: WebSocket) -> None:
        _ = ws_connection.ping(b"", timeout=2.0)
        assert not ws_connection.closed

    def test_ping_max_size(self, ws_connection: WebSocket) -> None:
        _ = ws_connection.ping(b"X" * 125, timeout=2.0)
        assert not ws_connection.closed

    def test_ping_too_large_raises(self, ws_connection: WebSocket) -> None:
        with pytest.raises(WebSocketError):
            _ = ws_connection.ping(b"X" * 126, timeout=2.0)

    def test_ping_default_payload(self, ws_connection: WebSocket) -> None:
        _ = ws_connection.ping(timeout=2.0)
        assert not ws_connection.closed

    def test_pong_valid_payload(self, ws_connection: WebSocket) -> None:
        _ = ws_connection.pong(b"heartbeat", timeout=2.0)
        assert not ws_connection.closed

    def test_pong_default_payload(self, ws_connection: WebSocket) -> None:
        _ = ws_connection.pong(timeout=2.0)
        assert not ws_connection.closed

    def test_pong_max_size(self, ws_connection: WebSocket) -> None:
        _ = ws_connection.pong(b"X" * 125, timeout=2.0)
        assert not ws_connection.closed

    def test_pong_too_large_raises(self, ws_connection: WebSocket) -> None:
        with pytest.raises(WebSocketError):
            _ = ws_connection.pong(b"X" * 126, timeout=2.0)

    def test_control_payload_limit_counts_bytes(self, ws_connection: WebSocket) -> None:
        # 63 characters, 189 bytes once encoded.
        with pytest.raises(WebSocketError):
            _ = ws_connection.ping("\u20ac" * 63, timeout=2.0)


class TestWebSocketLargeMessages:
    @pytest.mark.parametrize("size", [1024, 65536, 100_000, 500_000])
    def test_large_message_echo(self, ws_connection: WebSocket, size: int) -> None:
        payload: bytes = _pattern(size)
        _ = ws_connection.send(payload, timeout=10.0)
        data, _ = ws_connection.recv(timeout=10.0)
        assert len(data) == size
        assert data == payload

    def test_message_at_curl_frame_boundary(self, ws_connection: WebSocket) -> None:
        payload: bytes = _pattern(_MAX_FRAME)
        _ = ws_connection.send(payload, timeout=10.0)
        data, _ = ws_connection.recv(timeout=10.0)
        assert data == payload


@pytest.mark.filterwarnings("error::curl_cffi.utils.CurlCffiWarning")
class TestWebSocketRunForever:
    def test_run_forever_echo(
        self,
        session: Session,
        configurable_ws_server: ConfigurableWSServer,
        ws_config: Callable[..., None],
    ) -> None:
        ws_config(behavior=ServerBehavior.ECHO)

        received: list[bytes | str] = []
        messages_to_send: list[bytes] = [b"alpha", b"beta", b"gamma"]

        def on_open(ws: WebSocket) -> None:
            for m in messages_to_send:
                _ = ws.send(m, timeout=2.0)

        def on_message(ws: WebSocket, msg: bytes | str) -> None:
            received.append(msg)
            if len(received) == 3:
                ws.close()

        with session.ws_connect(
            configurable_ws_server.url, on_open=on_open, on_message=on_message
        ) as ws:
            ws.run_forever()

        assert len(received) == 3
        assert received == messages_to_send

    def test_run_forever_server_closes(
        self,
        session: Session,
        configurable_ws_server: ConfigurableWSServer,
        ws_config: Callable[..., None],
    ) -> None:
        ws_config(behavior=ServerBehavior.CLOSE_AFTER_N, close_after_n=1)

        close_code: int | None = None

        def on_open(ws: WebSocket) -> None:
            _ = ws.send(b"trigger", timeout=2.0)

        def on_close(ws: WebSocket, code: int, reason: str) -> None:
            nonlocal close_code
            close_code = code

        with session.ws_connect(
            configurable_ws_server.url, on_open=on_open, on_close=on_close
        ) as ws:
            ws.run_forever()

        assert close_code == WsCloseCode.OK

    def test_run_forever_enforces_max_message_size(
        self,
        session: Session,
        configurable_ws_server: ConfigurableWSServer,
        ws_config: Callable[..., None],
    ) -> None:
        """
        Verifies that run_forever() enforces the max_message_size restriction,
        gracefully closes the socket, and triggers the on_error callback.
        """
        two_mb = 2 * 1024 * 1024
        ws_config(behavior=ServerBehavior.LARGE_RESPONSE, response_size=two_mb)

        close_code: int | None = None
        errors: list[Exception] = []

        def on_open(ws: WebSocket) -> None:
            _ = ws.send(b"trigger", timeout=2.0)

        def on_error(ws: WebSocket, exc: Exception) -> None:
            errors.append(exc)

        def on_close(ws: WebSocket, code: int, reason: str) -> None:
            nonlocal close_code
            close_code = code

        with (
            session.ws_connect(
                configurable_ws_server.url,
                max_message_size=1024 * 1024,  # Client limit is 1MB
                on_open=on_open,
                on_error=on_error,
                on_close=on_close,
            ) as ws,
            pytest.raises(WebSocketError),
        ):
            ws.run_forever()

        assert len(errors) == 1
        assert isinstance(errors[0], WebSocketError)
        assert errors[0].code == WsCloseCode.MESSAGE_TOO_BIG
        assert close_code == WsCloseCode.MESSAGE_TOO_BIG

    def test_run_forever_invalid_utf8_closes(self) -> None:
        """Ensures bad UTF-8 data correctly triggers a protocol drop."""
        mock_curl: Mock = Mock(spec=Curl)
        ws: WebSocket = WebSocket(curl=mock_curl, skip_utf8_validation=False)
        ws.closed = False
        ws._sock_fd = 999
        ws._read_selector = Mock()
        ws._write_selector = Mock()

        class MockFrameMeta:
            def __init__(self) -> None:
                self.flags = CurlWsFlag.TEXT
                self.bytesleft = 0

        # Simulate receiving invalid utf8
        mock_curl.ws_recv.return_value = (b"\xff\xfe", MockFrameMeta())
        mock_curl.ws_send.return_value = 0  # Dummy mock for the auto-close call
        close_codes: list[int] = []

        def on_close(w, code, reason) -> None:
            close_codes.append(code)

        ws._emitters["close"] = on_close
        ws._emitters["message"] = lambda w, m: None

        with pytest.raises(WebSocketError) as exc:
            ws.run_forever()

        assert exc.value.code == WsCloseCode.INVALID_DATA
        assert close_codes == [WsCloseCode.INVALID_DATA]

    def test_run_forever_exhausts_retries(self) -> None:
        """Verifies that transient errors exceeding retry limits abort the loop."""
        mock_curl: Mock = Mock(spec=Curl)
        strategy: WebSocketRetryStrategy = WebSocketRetryStrategy(
            retry=True, count=2, delay=0.001
        )
        ws: WebSocket = WebSocket(curl=mock_curl, ws_retry=strategy)
        ws.closed = False
        ws._sock_fd = 999
        ws._read_selector = Mock()

        mock_curl.ws_recv.side_effect = CurlError("SSL Error", CurlECode.RECV_ERROR)

        errors: list[Exception] = []

        def on_error(w, exc) -> None:
            errors.append(exc)

        ws._emitters["error"] = on_error

        with pytest.raises(CurlError):
            ws.run_forever()

        assert len(errors) == 1
        assert isinstance(errors[0], CurlError)
        assert errors[0].code == CurlECode.RECV_ERROR


class TestWebSocketCloseAndState:
    def test_graceful_close(self, ws_connection: WebSocket) -> None:
        ws_connection.close(WsCloseCode.OK, b"goodbye")
        assert ws_connection.closed

    def test_close_idempotent(self, ws_connection: WebSocket) -> None:
        ws_connection.close()
        ws_connection.close()
        assert ws_connection.closed

    def test_recv_after_close_raises(self, ws_connection: WebSocket) -> None:
        ws_connection.close()
        with pytest.raises(WebSocketClosed):
            _ = ws_connection.recv(timeout=1.0)

    def test_send_after_close_raises(self, ws_connection: WebSocket) -> None:
        ws_connection.close()
        with pytest.raises((WebSocketClosed, WebSocketError)):
            _ = ws_connection.send(b"test", timeout=1.0)

    def test_recv_fragment_after_close_raises_with_code(
        self, ws_connection: WebSocket
    ) -> None:
        ws_connection.close(4000)
        with pytest.raises(WebSocketClosed) as exc_info:
            _ = ws_connection.recv_fragment()
        assert exc_info.value.code == 4000

    def test_close_code_extraction(
        self,
        session: Session,
        configurable_ws_server: ConfigurableWSServer,
        ws_config: Callable[..., None],
    ) -> None:
        ws_config(
            behavior=ServerBehavior.CLOSE_AFTER_N,
            close_after_n=1,
            close_code=1001,
            close_reason="going away",
        )

        ws: WebSocket = session.ws_connect(configurable_ws_server.url, autoclose=False)
        try:
            _ = ws.send(b"trigger", timeout=2.0)
            _ = ws.recv(timeout=5.0)  # Receive Echo
            _, flags = ws.recv(timeout=5.0)  # Receive Close
            assert flags & CurlWsFlag.CLOSE
            assert ws.close_code == 1001
            assert ws.close_reason == "going away"
        finally:
            ws.close()

    @pytest.mark.parametrize(
        "code,expected_valid",
        [
            (1000, True),
            (1001, True),
            (1002, True),
            (1003, True),
            (1007, True),
            (1008, True),
            (1009, True),
            (3000, True),
            (1012, True),
            (1013, True),
            (1014, True),
            (1016, False),
            (2000, False),
        ],
    )
    def test_valid_close_codes(
        self,
        session: Session,
        configurable_ws_server: ConfigurableWSServer,
        ws_config: Callable[..., None],
        code: int,
        expected_valid: bool,
    ) -> None:
        ws_config(behavior=ServerBehavior.ECHO)
        ws: WebSocket = session.ws_connect(configurable_ws_server.url)
        try:
            ws.close(code, b"test")
            assert ws.close_code == (
                code if expected_valid else WsCloseCode.INTERNAL_ERROR
            )
        except WebSocketError:
            if expected_valid:
                pytest.fail(f"Close code {code} should be valid")

    @pytest.mark.parametrize(
        "code,valid",
        [
            (1000, True),
            (1014, True),
            (3000, True),
            (1016, False),
            (2000, False),
            (1006, False),
        ],
    )
    def test_inbound_close_code_validation(self, code: int, valid: bool) -> None:
        """_unpack_close_frame is on BaseWebSocket, so this covers both clients."""
        ws: WebSocket = WebSocket(curl=Mock(spec=Curl))
        frame: bytes = struct.pack("!H", code) + b"bye"
        if valid:
            assert ws._unpack_close_frame(frame) == (code, "bye")
        else:
            with pytest.raises(WebSocketError):
                _ = ws._unpack_close_frame(frame)

    def test_close_with_long_reason(
        self,
        session: Session,
        configurable_ws_server: ConfigurableWSServer,
        ws_config: Callable[..., None],
    ) -> None:
        ws_config(behavior=ServerBehavior.ECHO)
        ws: WebSocket = session.ws_connect(configurable_ws_server.url)
        long_reason: bytes = b"x" * 123
        ws.close(WsCloseCode.OK, long_reason)
        assert ws.closed

    def test_utf8_close_reason_roundtrip(
        self,
        session: Session,
        configurable_ws_server: ConfigurableWSServer,
        ws_config: Callable[..., None],
    ) -> None:
        """
        Ensures that non-ASCII close reasons (e.g., emojis/UTF-8 strings)
        are cleanly encoded, sent, and unpacked without raising unicode decode errors.
        """
        ws_config(behavior=ServerBehavior.ECHO)
        ws: WebSocket = session.ws_connect(configurable_ws_server.url, autoclose=False)

        unicode_reason = "Server maintenance 🚀"
        try:
            ws.close(WsCloseCode.GOING_AWAY, unicode_reason)
            assert ws.closed
            assert ws.close_code == WsCloseCode.GOING_AWAY
            assert ws.close_reason == unicode_reason
        finally:
            ws.close()

    def test_unpack_empty_close_frame(self) -> None:
        ws: WebSocket = WebSocket(curl=Mock())
        code, reason = ws._unpack_close_frame(b"")
        assert code == WsCloseCode.UNKNOWN
        assert reason == ""

    def test_unpack_code_only_close_frame(self) -> None:
        ws: WebSocket = WebSocket(curl=Mock())
        code, reason = ws._unpack_close_frame(b"\x03\xe8")
        assert code == WsCloseCode.OK
        assert reason == ""

    def test_session_close_closes_live_websockets(
        self,
        configurable_ws_server: ConfigurableWSServer,
        ws_config: Callable[..., None],
    ) -> None:
        """Closing a Session must close any WebSocket still open on it."""
        ws_config(behavior=ServerBehavior.ECHO)
        with Session[Response](verify=False) as session:
            ws: WebSocket = session.ws_connect(configurable_ws_server.url)
            assert not ws.closed

            session.close()
            assert ws.closed, "session.close() left a live WebSocket running"
            with pytest.raises((WebSocketClosed, WebSocketError)):
                _ = ws.send(b"should fail")

    def test_websocket_accounting_across_lifecycle(
        self,
        configurable_ws_server: ConfigurableWSServer,
        ws_config: Callable[..., None],
    ) -> None:
        """The tracking set must track live connections through every exit path."""
        ws_config(behavior=ServerBehavior.ECHO)
        with Session[Response](verify=False) as session:

            def live() -> int:
                return len(session._websockets)  # pyright: ignore[reportPrivateUsage]

            assert live() == 0

            ws: WebSocket = session.ws_connect(configurable_ws_server.url)
            assert live() == 1
            ws.close()
            assert ws.closed

            # sync WebSocket has no session back-reference, so nothing
            # discards on close/terminate.
            ws2: WebSocket = session.ws_connect(configurable_ws_server.url)
            assert live() == 2
            ws2.terminate()
            assert ws2.closed

            with pytest.raises((CurlError, WebSocketError)):
                _ = session.ws_connect("ws://127.0.0.1:1/nonexistent", timeout=5.0)
            assert live() == 2, "failed connect registered a WebSocket"


class TestWebSocketIterator:
    def test_for_in_loop(
        self,
        session: Session,
        configurable_ws_server: ConfigurableWSServer,
        ws_config: Callable[..., None],
    ) -> None:
        messages: list[bytes] = [b"one", b"two", b"three"]
        ws_config(behavior=ServerBehavior.BROADCAST, broadcast_messages=messages)

        with session.ws_connect(configurable_ws_server.url) as ws:
            received: list[bytes] = []

            for msg in ws:
                received.append(msg)
                if len(received) == len(messages):
                    break

            assert len(received) == 3
            assert received == messages

    def test_iterator_skips_control_frames(
        self,
        session: Session,
        configurable_ws_server: ConfigurableWSServer,
        ws_config: Callable[..., None],
    ) -> None:
        ws_config(behavior=ServerBehavior.SEND_PINGS)

        with session.ws_connect(configurable_ws_server.url) as ws:
            received: list[bytes] = []

            for msg in ws:
                received.append(msg)
                if len(received) == 2:
                    break

            assert received == [b"data_1", b"data_2"]


class TestWebSocketParameterBoundaries:
    def test_client_enforces_max_message_size(
        self,
        session: Session,
        configurable_ws_server: ConfigurableWSServer,
        ws_config: Callable[..., None],
    ) -> None:
        two_mb = 2 * 1024 * 1024
        ws_config(behavior=ServerBehavior.LARGE_RESPONSE, response_size=two_mb)

        with session.ws_connect(
            configurable_ws_server.url,
            max_message_size=1024 * 1024,  # Client limit is 1MB
        ) as ws:
            _ = ws.send(b"trigger", timeout=2.0)

            with pytest.raises(WebSocketError) as exc_info:
                _ = ws.recv(timeout=5.0)

            assert exc_info.value.code == CurlECode.TOO_LARGE


class TestWebSocketFragmentationFix:
    """Tests validating the manual memoryview slicing & boundary math."""

    def test_send_timeout_partial_write_terminates_connection(self) -> None:
        """
        Verifies that if a send() operation times out after writing a partial
        amount of bytes (offset > 0), the connection is forcefully terminated
        (closed = True) and the original exception is re-raised intact.
        """
        mock_curl: Mock = Mock(spec=Curl)
        ws: WebSocket = WebSocket(curl=mock_curl)
        ws.closed = False
        ws._sock_fd = 999

        mock_selector: Mock = Mock()
        ws._read_selector = mock_selector
        ws._write_selector = mock_selector

        # Simulate a partial write followed by a transient block
        call_count = 0

        def mock_ws_send(chunk: memoryview, flags: int) -> int:
            nonlocal call_count
            call_count += 1
            if call_count == 1:
                return 10000  # Partial write
            raise CurlError("EAGAIN", CurlECode.AGAIN)

        mock_curl.ws_send.side_effect = mock_ws_send

        # Simulate write selector timing out (returns empty list)
        mock_selector.select.return_value = []

        # We attempt to send a 100,000-byte payload
        with pytest.raises(WebSocketTimeout) as exc_info:
            _ = ws.send(b"X" * 100000, timeout=0.05)

        # Ensure the original timeout exception bubbles up without masking
        assert exc_info.value.code == CurlECode.OPERATION_TIMEDOUT

        # The connection must have been forcefully terminated to prevent frame desync
        assert ws.closed is True

        # Subsequent calls to send must immediately fail with WebSocketClosed
        with pytest.raises(WebSocketClosed):
            _ = ws.send(b"data", timeout=1.0)

    def test_send_timeout_zero_write_closes_connection(self) -> None:
        """
        Verifies that if a send() operation times out before writing a single byte
        (offset == 0), the connection closes because libcurl may already have
        buffered the frame without reporting any payload bytes sent.
        """
        mock_curl: Mock = Mock(spec=Curl)
        ws: WebSocket = WebSocket(curl=mock_curl)
        ws.closed = False
        ws._sock_fd = 999

        mock_selector: Mock = Mock()
        ws._read_selector = mock_selector
        ws._write_selector = mock_selector

        # Simulate socket blocking immediately (no bytes written)
        mock_curl.ws_send.side_effect = CurlError("EAGAIN", CurlECode.AGAIN)

        # Simulate write selector timing out (returns empty list)
        mock_selector.select.return_value = []

        # Since offset == 0, it raises a standard WebSocketTimeout
        with pytest.raises(WebSocketTimeout):
            _ = ws.send(b"X" * 100000, timeout=0.05)

        # Pending libcurl frame state cannot be replaced by a later send.
        assert ws.closed is True
        mock_curl.close.assert_called_once()

    def test_partial_write_exact_boundary_resumption(
        self, ws_connection: WebSocket
    ) -> None:
        """A partial write must resume with exactly the remainder of the frame.

        Asserts the invariant, not a call count: POSIX does not guarantee that
        send() accepts the whole buffer, so the number of ws_send() calls is
        kernel dependent. See issue #849. The async twin of this test is in
        test_async_websockets.py -- keep them in step.
        """
        original_ws_send: Callable[..., int] = ws_connection.curl.ws_send
        offered: list[int] = []
        accepted: list[int] = []

        def mock_ws_send(chunk: memoryview, flags: int) -> int:
            # Truncate the first call so the resumption path is exercised even
            # on kernels that always accept the whole buffer.
            truncate: bool = not offered
            offered.append(len(chunk))
            try:
                if truncate:
                    n_sent: int = original_ws_send(chunk[:10000], flags)
                else:
                    n_sent = original_ws_send(chunk, flags)
            except BaseException:
                accepted.append(0)  # keep the logs index-aligned on EAGAIN
                raise
            accepted.append(n_sent)
            return n_sent

        payload: bytes = _pattern(100000)
        with unittest.mock.patch.object(
            ws_connection.curl, "ws_send", side_effect=mock_ws_send
        ):
            _ = ws_connection.send(payload, timeout=5.0)
            data, _ = ws_connection.recv(timeout=10.0)

        assert data == payload

        # Every call must offer exactly the remainder of the open frame. More
        # trips libcurl's "unaligned frame size"; less silently drops bytes.
        offset: int = 0
        for offered_len, accepted_len in zip(offered, accepted, strict=True):
            expected: int = min(
                _MAX_FRAME - (offset % _MAX_FRAME), len(payload) - offset
            )
            assert (
                offered_len == expected
            ), f"at offset {offset}: offered {offered_len}, expected {expected}"
            offset += accepted_len

        assert offset == len(payload)
        assert any(
            a < o for o, a in zip(offered, accepted, strict=True)
        ), "no partial write occurred, the resumption path was not exercised"

    def test_send_eagain_retry_preserves_state(self, ws_connection: WebSocket) -> None:
        """EAGAIN must not corrupt frame boundary state.

        The retry has to present the identical buffer and flags. Total call
        count is kernel dependent (issue #849), so it is not asserted.
        """
        original_ws_send: Callable[..., int] = ws_connection.curl.ws_send
        offers: list[tuple[int, int]] = []

        def mock_ws_send(chunk: memoryview, flags: int) -> int:
            offers.append((len(chunk), flags))
            if len(offers) == 1:
                raise CurlError("Simulated EAGAIN", CurlECode.AGAIN)
            return original_ws_send(chunk, flags)

        payload: bytes = _pattern(100000)
        with unittest.mock.patch.object(
            ws_connection.curl, "ws_send", side_effect=mock_ws_send
        ):
            _ = ws_connection.send(payload, timeout=5.0)
            data, _ = ws_connection.recv(timeout=10.0)

        assert data == payload
        assert len(offers) >= 3
        assert (
            offers[1] == offers[0]
        ), "the retry after EAGAIN changed the frame boundary or the flags"


class TestWebSocketRobustness:
    def test_raw_fragment_assembly_with_interleaved_control_frames(self) -> None:
        """
        Proves that the inline recv() loop correctly reassembles fragmented data
        even when PING and PONG frames are maliciously interleaved by the server.
        """
        mock_curl: Mock = Mock(spec=Curl)
        ws: WebSocket = WebSocket(curl=mock_curl)
        ws.closed = False
        ws._sock_fd = 999

        # Support the zero-payload auto-PONG flush triggered by intercepted PINGs
        mock_curl.ws_send.return_value = 0

        # Mock the selectors to prevent registering the fake FD (999) with the OS
        mock_selector: Mock = Mock()
        ws._read_selector = mock_selector
        ws._write_selector = mock_selector

        class MockFrameMeta:
            def __init__(self, flags: int, bytesleft: int = 0) -> None:
                self.flags: int = flags
                self.bytesleft: int = bytesleft

        mock_sequence: list[tuple[bytes, MockFrameMeta]] = [
            (b"Chunk 1 ", MockFrameMeta(CurlWsFlag.TEXT | CurlWsFlag.CONT)),
            (b"ping_payload", MockFrameMeta(CurlWsFlag.PING)),
            (b"pong_payload", MockFrameMeta(CurlWsFlag.PONG)),
            (b"Chunk 2", MockFrameMeta(CurlWsFlag.TEXT)),
        ]

        iterator: Iterator[tuple[bytes, MockFrameMeta]] = iter(mock_sequence)
        mock_curl.ws_recv.side_effect = lambda: next(iterator)

        # Call the synchronous receive loop directly
        data, flags = ws.recv(timeout=5.0)

        # The loop MUST have bypassed the PING and PONG and cleanly glued the text.
        assert data == b"Chunk 1 Chunk 2"
        assert flags == CurlWsFlag.TEXT

    def test_abrupt_server_eof(self) -> None:
        """Verifies that an abrupt TCP drop resolves as an ABNORMAL_CLOSURE."""
        mock_curl: Mock = Mock(spec=Curl)
        ws: WebSocket = WebSocket(curl=mock_curl)
        ws.closed = False
        ws._sock_fd = 999
        ws._read_selector = Mock()
        mock_curl.ws_recv.side_effect = CurlError("EOF", CurlECode.GOT_NOTHING)

        with pytest.raises(WebSocketClosed) as exc:
            _ = ws.recv(timeout=1.0)
        assert exc.value.code == WsCloseCode.ABNORMAL_CLOSURE

    def test_send_write_stall_protection(self) -> None:
        """Prevents infinite spin-loops if the OS buffer refuses to accept bytes."""
        mock_curl: Mock = Mock(spec=Curl)
        ws: WebSocket = WebSocket(curl=mock_curl)
        ws.closed = False
        ws._sock_fd = 999
        ws._read_selector = Mock()
        ws._write_selector = Mock()
        mock_curl.ws_send.return_value = 0  # 0 bytes sent repeatedly

        with pytest.raises(WebSocketError) as exc:
            _ = ws.send(b"data", timeout=1.0)

        assert "Writer stalled" in str(exc.value)
        assert exc.value.code == CurlECode.WRITE_ERROR

    def test_fragmented_reassembly_resumption_after_timeout(self) -> None:
        """
        Test that if a read timeout occurs in the middle of a fragmented message,
        the accumulated chunks are safely persisted, and the message can be fully
        reassembled on subsequent recv() calls.
        """

        mock_curl: MagicMock = MagicMock()
        ws: WebSocket = WebSocket(curl=mock_curl)
        ws._sock_fd = 12  # Mock socket descriptor to bypass _get_sock_fd check
        ws._read_selector = MagicMock()  # Mock selector

        # Simulate a fragmented message:
        # Fragment 1 (TEXT + CONT), then Fragment 2 (TEXT final)
        # We use MagicMock to simulate the read-only C struct returned by libcurl
        frame1: MagicMock = MagicMock()
        frame1.flags = CurlWsFlag.TEXT | CurlWsFlag.CONT
        frame1.bytesleft = 0

        frame2: MagicMock = MagicMock()
        frame2.flags = CurlWsFlag.TEXT
        frame2.bytesleft = 0

        # ws_recv will return Fragment 1 first. On the second iteration, it raises
        # a transient EAGAIN, causing the selector to select and time out.
        # On the next call to recv(), it returns the final Fragment 2.
        call_count = 0

        def mock_ws_recv() -> (
            tuple[Literal[b"hello_"], MagicMock] | tuple[Literal[b"world"], MagicMock]
        ):
            nonlocal call_count
            call_count += 1
            if call_count == 1:
                return b"hello_", frame1
            elif call_count == 2:
                raise CurlError("Transient EAGAIN", CurlECode.AGAIN)
            elif call_count == 3:
                return b"world", frame2
            raise AssertionError("Unexpected call to ws_recv")

        mock_curl.ws_recv.side_effect = mock_ws_recv

        # Mock the selector to return empty list, simulating a select timeout
        ws._read_selector.select.return_value = []

        # 1. First attempt: Call recv() with a timeout. It should read Fragment 1,
        # hit EAGAIN, block on select(), time out, and raise WebSocketTimeout.
        with pytest.raises(WebSocketTimeout):
            _ = ws.recv(timeout=0.1)

        # VERIFY STATE PRESERVATION: Option B must have safely saved the partial state
        assert len(ws._recv_chunks) == 1
        assert ws._recv_chunks[0] == b"hello_"
        assert ws._recv_msg_size == 6

        # 2. Second attempt: Call recv() again. It should resume cleanly,
        # bypass select, read Fragment 2, and return the complete reassembled payload.
        msg, flags = ws.recv()

        assert msg == b"hello_world"
        assert flags == CurlWsFlag.TEXT

        # VERIFY STATE CLEANUP: The instance states must be completely cleared
        # on success
        assert len(ws._recv_chunks) == 0
        assert ws._recv_msg_size == 0

    def test_fragmented_reassembly_aborted_on_server_eof(self) -> None:
        """
        Test that if the server disconnects (EOF/GOT_NOTHING) in the middle
        of a fragmented message, the connection is forcefully closed, state
        is discarded, and a WebSocketClosed exception is raised.
        """

        mock_curl: MagicMock = MagicMock()
        ws: WebSocket = WebSocket(curl=mock_curl)
        ws._sock_fd = 12
        ws._read_selector = MagicMock()

        frame1: MagicMock = MagicMock()
        frame1.flags = CurlWsFlag.TEXT | CurlWsFlag.CONT
        frame1.bytesleft = 0

        call_count = 0

        def mock_ws_recv() -> tuple[Literal[b"partial_data"], MagicMock]:
            nonlocal call_count
            call_count += 1
            if call_count == 1:
                return b"partial_data", frame1
            elif call_count == 2:
                raise CurlError("Server EOF", CurlECode.GOT_NOTHING)
            raise AssertionError("Unexpected call to ws_recv")

        mock_curl.ws_recv.side_effect = mock_ws_recv

        # Attempt to read the fragmented message
        with pytest.raises(WebSocketClosed) as exc_info:
            _ = ws.recv()

        assert exc_info.value.code == WsCloseCode.ABNORMAL_CLOSURE

        # VERIFY LEAK PREVENTION: The connection must be closed
        # and the partial buffer cleared
        assert ws.closed is True
        assert len(ws._recv_chunks) == 0
        assert ws._recv_msg_size == 0

    def test_large_text_message(self, ws_connection: WebSocket) -> None:
        payload: str = _text_pattern(100_000)
        _ = ws_connection.send_str(payload, timeout=10.0)
        response: str = ws_connection.recv_str(timeout=10.0)
        assert response == payload


class TestWebSocketSIMDEdgeCases:
    """Probes the C-layer SIMD / Scalar XOR boundary behavior via the API."""

    @pytest.mark.parametrize("extra_bytes", [0, 1, 2, 3, 4, 7, 31, 33, 63, 65])
    def test_simd_masking_tail_logic(
        self, ws_connection: WebSocket, extra_bytes: int
    ) -> None:
        size: int = 128 + extra_bytes
        payload: bytes = bytes((i * 7 + 13) % 251 for i in range(size))

        _ = ws_connection.send_binary(payload, timeout=5.0)
        data, _ = ws_connection.recv(timeout=5.0)

        assert len(data) == size
        assert data == payload

    def test_mask_index_persistence_across_unaligned_fragments(
        self, ws_connection: WebSocket
    ) -> None:
        chunks: list[bytes] = [b"ABC", b"DEF", b"GHI", b"JKL"]

        _ = ws_connection.send(chunks[0], flags=CurlWsFlag.BINARY | CurlWsFlag.CONT)
        _ = ws_connection.send(chunks[1], flags=CurlWsFlag.BINARY | CurlWsFlag.CONT)
        _ = ws_connection.send(chunks[2], flags=CurlWsFlag.BINARY | CurlWsFlag.CONT)
        _ = ws_connection.send(chunks[3], flags=CurlWsFlag.BINARY)

        data, _ = ws_connection.recv(timeout=5.0)
        assert data == b"ABCDEFGHIJKL"

    def test_unaligned_memory_source(self, ws_connection: WebSocket) -> None:
        base_data: bytes = b"AlignmentPadding" + b"ActualPayload" * 10
        unaligned_view: memoryview = memoryview(base_data)[7:]

        _ = ws_connection.send(unaligned_view, timeout=5.0)
        data, _ = ws_connection.recv(timeout=5.0)
        assert data == bytes(unaligned_view)

    def test_manual_fragmentation_with_empty_chunks(
        self, ws_connection: WebSocket
    ) -> None:
        _ = ws_connection.send(b"Start", flags=CurlWsFlag.TEXT | CurlWsFlag.CONT)
        _ = ws_connection.send(b"", flags=CurlWsFlag.TEXT | CurlWsFlag.CONT)
        _ = ws_connection.send(b"End", flags=CurlWsFlag.TEXT)

        response: str = ws_connection.recv_str(timeout=5.0)
        assert response == "StartEnd"

    @pytest.mark.parametrize("length", [1, 3, 15, 31, 63, 127])
    def test_simd_to_scalar_transition_boundaries(
        self, ws_connection: WebSocket, length: int
    ) -> None:
        payload: bytes = _pattern(length)
        _ = ws_connection.send(payload, timeout=5.0)
        data, _ = ws_connection.recv(timeout=5.0)
        assert data == payload
        assert len(data) == length


class TestWebSocketMultithreadedDispatch:
    """Verifies that multiple independent synchronous clients run cleanly on threads."""

    def test_multithreaded_event_loops(
        self, configurable_ws_server: ConfigurableWSServer
    ) -> None:
        """
        Runs multiple threads simultaneously hitting the C-layer XOR masking
        functions. Ensures the global static CPU capability caching and memory
        doesn't crash or corrupt across threads.
        """

        def run_thread(thread_id: int) -> None:
            with (
                Session[Response]() as s,
                s.ws_connect(configurable_ws_server.url) as ws,
            ):
                for i in range(50):
                    payload: bytes = f"thread_{thread_id}_msg_{i}".encode()
                    _ = ws.send(payload, timeout=2.0)
                    data, _ = ws.recv(timeout=2.0)
                    assert data == payload

        with concurrent.futures.ThreadPoolExecutor(max_workers=5) as executor:
            futures: list[Future[None]] = [
                executor.submit(run_thread, i) for i in range(5)
            ]
            for future in concurrent.futures.as_completed(futures):
                future.result()  # Will raise if assertion failed or exception occurred


class TestWebSocketRetryStrategy:
    def test_recv_retry_strategy_success(self) -> None:
        """
        Verifies that the WebSocketRetryStrategy successfully recovers from
        transient CurlECode.RECV_ERROR anomalies, retrying up to the limit
        and then returning the final successful frame.
        """
        mock_curl: Mock = Mock(spec=Curl)
        # Configure a retry strategy on the client
        strategy: WebSocketRetryStrategy = WebSocketRetryStrategy(
            retry=True, count=2, delay=0.01
        )
        ws: WebSocket = WebSocket(curl=mock_curl, ws_retry=strategy)
        ws.closed = False
        ws._sock_fd = 999

        # Mock selectors to avoid registering the fake FD
        mock_selector: Mock = Mock()
        ws._read_selector = mock_selector
        ws._write_selector = mock_selector

        class MockFrameMeta:
            def __init__(self) -> None:
                self.flags: int = CurlWsFlag.TEXT
                self.bytesleft: int = 0

        call_count = 0

        def mock_ws_recv() -> tuple[bytes, MockFrameMeta]:
            nonlocal call_count
            call_count += 1
            if call_count < 3:
                # Fail the first 2 times with a retryable code
                raise CurlError("Transient connection error", CurlECode.RECV_ERROR)
            return b"recovered_message", MockFrameMeta()

        mock_curl.ws_recv.side_effect = mock_ws_recv

        # Should recover on the third attempt and return the data
        data, flags = ws.recv(timeout=5.0)
        assert data == b"recovered_message"
        assert flags == CurlWsFlag.TEXT
        assert call_count == 3

    def test_recv_retry_expired_deadline_raises_timeout(self) -> None:
        """An expired deadline mid-retry must surface as WebSocketTimeout."""
        mock_curl: Mock = Mock(spec=Curl)
        strategy: WebSocketRetryStrategy = WebSocketRetryStrategy(
            retry=True, count=5, delay=5.0
        )
        ws: WebSocket = WebSocket(curl=mock_curl, ws_retry=strategy)
        ws.closed = False
        ws._sock_fd = 999
        ws._read_selector = Mock()
        ws._write_selector = Mock()

        mock_curl.ws_recv.side_effect = CurlError(
            "Transient connection error", CurlECode.RECV_ERROR
        )

        with pytest.raises(WebSocketTimeout):
            _ = ws.recv(timeout=0.1)

    def test_recv_retry_honours_backoff_delay(self) -> None:
        """Retries without a deadline must still wait out the backoff."""
        mock_curl: Mock = Mock(spec=Curl)
        strategy: WebSocketRetryStrategy = WebSocketRetryStrategy(
            retry=True, count=2, delay=0.02
        )
        ws: WebSocket = WebSocket(curl=mock_curl, ws_retry=strategy)
        ws.closed = False
        ws._sock_fd = 999
        ws._read_selector = Mock()
        ws._write_selector = Mock()

        mock_curl.ws_recv.side_effect = CurlError(
            "Transient connection error", CurlECode.RECV_ERROR
        )

        with (
            unittest.mock.patch(f"{WebSocket.__module__}.sync_sleep") as mock_sleep,
            pytest.raises(CurlError),
        ):
            _ = ws.recv()

        assert mock_sleep.call_count == 2
        assert all(c.args[0] > 0 for c in mock_sleep.call_args_list)


class TestWebSocketPerformance:
    def test_high_volume_chatty_protocol(self, ws_connection: WebSocket) -> None:
        """
        Sends 2000 tiny frames to ensure the synchronous CFFI boundary remains
        lightning fast and doesn't leak memory.
        """
        for _ in range(2000):
            _ = ws_connection.send(b"K", timeout=1.0)
            data, _ = ws_connection.recv(timeout=1.0)
            assert data == b"K"


class TestWebSocketVerifyArguments:
    """``Session.ws_connect`` applies TLS verification exactly like ``request``."""

    SESSION_CA: Final[str] = "/tmp/session-ca.pem"
    REQUEST_CA: Final[str] = "/tmp/request-ca.pem"
    HTTP_URL: Final[str] = "https://127.0.0.1:9/"
    WS_URL: Final[str] = "wss://127.0.0.1:9/"
    TLS_OPTIONS: Final[frozenset[CurlOpt]] = frozenset[CurlOpt](
        {
            CurlOpt.SSL_VERIFYPEER,
            CurlOpt.SSL_VERIFYHOST,
            CurlOpt.CAINFO,
            CurlOpt.PROXY_CAINFO,
        }
    )

    def _tls_state(self, connect: Callable[[], object]) -> dict[str, object]:
        """Run ``connect`` up to ``perform()`` and return the TLS state it set."""
        state: dict[str, object] = {}
        real_setopt: Callable[..., int] = Curl.setopt

        def setopt(curl: Curl, option: CurlOpt, value: object) -> int:
            if option in self.TLS_OPTIONS:
                state[option.name] = value
            return real_setopt(curl, option, value)

        def perform(curl: Curl, *_: object, **__: object) -> None:
            state["skip_cacert"] = (
                curl._skip_cacert  # pyright: ignore[reportPrivateUsage]
            )
            raise _StopBeforeIO

        with (
            unittest.mock.patch.object(Curl, "setopt", setopt),
            unittest.mock.patch.object(Curl, "perform", perform),
            pytest.raises(_StopBeforeIO),
        ):
            _ = connect()
        return state

    def test_session_ca_bundle_kept_with_verify_true(self) -> None:
        """``verify=True`` on the call must not discard the session CA bundle."""
        with Session[Response](
            verify=self.SESSION_CA  # pyright: ignore[reportArgumentType]
        ) as session:
            state: dict[str, object] = self._tls_state(
                lambda: session.ws_connect(self.WS_URL, verify=True)
            )
        assert state.get("CAINFO") == self.SESSION_CA

    @pytest.mark.parametrize("session_verify", [True, False, SESSION_CA])
    @pytest.mark.parametrize("request_verify", [None, True, False, REQUEST_CA])
    def test_matches_session_request(
        self, session_verify: bool | str, request_verify: bool | str | None
    ) -> None:
        """Every session/call combination sets the same options as ``request``."""
        with Session[Response](
            verify=session_verify  # pyright: ignore[reportArgumentType]
        ) as session:
            expected: dict[str, object] = self._tls_state(
                lambda: session.get(
                    self.HTTP_URL,
                    verify=request_verify,  # pyright: ignore[reportArgumentType]
                )
            )
            actual: dict[str, object] = self._tls_state(
                lambda: session.ws_connect(self.WS_URL, verify=request_verify)
            )
        assert actual == expected

    def test_standalone_connect_verifies_by_default(self) -> None:
        """A ``WebSocket`` connected without a session still verifies certificates."""
        state: dict[str, object] = self._tls_state(
            lambda: WebSocket().connect(self.WS_URL)
        )
        assert state.get("SSL_VERIFYPEER") != 0
        assert state["skip_cacert"] is False


class TestWebSocketProxyArguments:
    """``Session.ws_connect`` picks proxies exactly like ``request``."""

    SESSION_PROXIES: Final[ProxySpec] = {"all": "http://127.0.0.1:8/"}
    PROXIES: Final[ProxySpec] = {"all": "http://127.0.0.1:9/"}
    PROXY: Final[str] = "http://127.0.0.1:7/"
    HTTP_URL: Final[str] = "https://127.0.0.1:9/"
    WS_URL: Final[str] = "wss://127.0.0.1:9/"

    def _proxy_set(self, connect: Callable[[], object]) -> object:
        """Run ``connect`` up to ``perform()`` and return the proxy it set."""
        seen: dict[str, object] = {}
        real_setopt: Callable[..., int] = Curl.setopt

        def setopt(curl: Curl, option: CurlOpt, value: object) -> int:
            if option == CurlOpt.PROXY:
                seen["proxy"] = value
            return real_setopt(curl, option, value)

        with (
            unittest.mock.patch.object(Curl, "setopt", setopt),
            unittest.mock.patch.object(Curl, "perform", side_effect=_StopBeforeIO),
            pytest.raises(_StopBeforeIO),
        ):
            _ = connect()
        return seen.get("proxy")

    def test_proxy_and_proxies_are_rejected(self) -> None:
        """Passing both is refused, as it is by ``request`` and the async client."""
        with (
            Session[Response]() as session,
            unittest.mock.patch.object(Curl, "perform", side_effect=_StopBeforeIO),
            pytest.raises(TypeError, match="Cannot specify both"),
        ):
            _ = session.ws_connect(self.WS_URL, proxy=self.PROXY, proxies=self.PROXIES)

    @pytest.mark.parametrize(
        "session_proxies", [None, SESSION_PROXIES], ids=["no-session", "session"]
    )
    @pytest.mark.parametrize(
        ("proxy", "proxies"),
        [(None, None), (PROXY, None), (None, PROXIES), (None, {})],
        ids=["inherit", "proxy", "proxies", "opt-out"],
    )
    def test_matches_session_request(
        self,
        session_proxies: ProxySpec | None,
        proxy: str | None,
        proxies: ProxySpec | None,
    ) -> None:
        """Every session/call combination picks the same proxy as ``request``."""
        with Session[Response](proxies=session_proxies) as session:
            expected: object = self._proxy_set(
                lambda: session.get(self.HTTP_URL, proxy=proxy, proxies=proxies)
            )
            actual: object = self._proxy_set(
                lambda: session.ws_connect(self.WS_URL, proxy=proxy, proxies=proxies)
            )
        assert actual == expected
