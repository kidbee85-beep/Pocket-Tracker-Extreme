// easy interfaces
void *curl_easy_init();
int _curl_easy_setopt(void *curl, int option, void *param);
int _curl_easy_getinfo_socket(void *curl, int option, uintptr_t *result);
int curl_easy_getinfo(void *curl, int option, void *ret);
int curl_easy_perform(void *curl);
void curl_easy_cleanup(void *curl);
void curl_easy_reset(void *curl);
int curl_easy_impersonate(void *curl, char *target, int default_headers);
void *curl_easy_duphandle(void *curl);
int curl_easy_upkeep(void *curl);
int curl_easy_pause(void *curl, int action);
const char *curl_easy_strerror(int code);

char *curl_version();

// slist interfaces
struct curl_slist {
   char *data;
   struct curl_slist *next;
};
struct curl_slist *curl_slist_append(struct curl_slist *list, char *string);
void curl_slist_free_all(struct curl_slist *list);

// callbacks
extern "Python" size_t buffer_callback(void *ptr, size_t size, size_t nmemb, void *userdata);
extern "Python" size_t write_callback(void *ptr, size_t size, size_t nmemb, void *userdata);
extern "Python" size_t read_buffer_callback(void *ptr, size_t size, size_t nmemb, void *userdata);
extern "Python" size_t read_callback(void *ptr, size_t size, size_t nmemb, void *userdata);
extern "Python" int seek_buffer_callback(void *userdata, int64_t offset, int origin);
extern "Python" int debug_function(void *curl, int type, char *data, size_t size, void *clientp);

// multi interfaces
struct CURLMsg {
   int msg;       /* what this message means */
   void *easy_handle; /* the handle it concerns */
   union {
     void *whatever;    /* message-specific data */
     int result;   /* return code for transfer */
   } data;
};
void *curl_multi_init();
int curl_multi_cleanup(void *curlm);
int curl_multi_add_handle(void *curlm, void *curl);
int curl_multi_remove_handle(void *curlm, void *curl);
int curl_multi_socket_action(void *curlm, int sockfd, int ev_bitmask, int *running_handle);
int curl_multi_setopt(void *curlm, int option, void* param);
int curl_multi_assign(void *curlm, int sockfd, void *sockptr);
int curl_multi_perform(void *curlm, int *running_handle);
int curl_multi_timeout(void *curlm, long *timeout_ms);
int curl_multi_wait(void *curlm, void *extra_fds, unsigned int extra_nfds, int timeout_ms, int *numfds);
int curl_multi_poll(void *curlm, void *extra_fds, unsigned int extra_nfds, int timeout_ms, int *numfds);
int curl_multi_wakeup(void *curlm);
const char *curl_multi_strerror(int code);
struct CURLMsg *curl_multi_info_read(void* curlm, int *msg_in_queue);

// multi callbacks
extern "Python" int socket_function(void *curl, int sockfd, int what, void *clientp, void *socketp);
extern "Python" int timer_function(void *curlm, int timeout_ms, void *clientp);

// share interfaces
void *curl_share_init();
int _curl_share_setopt(void *share, int option, void *param);
int curl_share_cleanup(void *share);
const char *curl_share_strerror(int code);

// share callbacks
extern "Python" void lock_function(void *handle, int data, int access, void *userptr);
extern "Python" void unlock_function(void *handle, int data, void *userptr);

// websocket
typedef int... curl_off_t;

struct curl_ws_frame {
  int age;              /* zero */
  int flags;            /* See the CURLWS_* defines */
  curl_off_t offset;    /* the offset of this data into the frame */
  curl_off_t bytesleft; /* pending payload bytes, -1 if decoded size unknown */
  size_t len;
  ...;
};

int curl_ws_recv(void *curl, void *buffer, size_t buflen, size_t *recv, const struct curl_ws_frame **meta);
int curl_ws_send(void *curl, const void *buffer, size_t buflen, size_t *sent, int fragsize, unsigned int sendflags);

// mime
void *curl_mime_init(void* curl);  // -> form
void *curl_mime_addpart(void *form);  // -> part/field
int curl_mime_name(void *field, char *name);
int curl_mime_data(void *field, char *name, int datasize);
int curl_mime_type(void *field, char *type);
int curl_mime_filename(void *field, char *filename);
int curl_mime_filedata(void *field, char *filename);
void curl_mime_free(void *form);
